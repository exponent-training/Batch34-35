package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
	public static void main(String[] args) {
		
		Student s= new Student();
		
		s.setSid(18);
		s.setSname("pqr1");
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session session=sf.openSession();
		
//		int i=(int)session.save(s);//serilable int
//		session.persist(s);//void
		
//		session.update(s);
//		session.saveOrUpdate(s);
		
		session.delete(s);
		session.beginTransaction().commit();
		
		
		
//		System.out.println(i);
		
	}

}
