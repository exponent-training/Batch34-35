package com.services;

public interface Services {
	
	void addStudentWithMultipleSubject();
	
	void getStudentWithMultipleSubject();
	
	void updateStudent();
	
	void updateStudentSubjectUsingSid();
	
	void deleteStudentAndSubjects();
	
	void deleteSubjectOnly();
	
	void deleteStudentOnly();
	
	
}
