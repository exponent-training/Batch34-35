package com.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.Student;
import com.model.Subject;
import com.util.HibernateUtil;

public class ServicesImpl implements Services {

	Scanner sc = new Scanner(System.in);
	SessionFactory sf = HibernateUtil.getFactory();

	@Override
	public void addStudentWithMultipleSubject() {

		Session session = sf.openSession();

		Student s = new Student();
		System.out.println("enter sname :");
		s.setSname(sc.next());

		System.out.println("How many Subject you want to add : ");
		int n = sc.nextInt();

		List<Subject> sublist = new ArrayList<Subject>();

		for (int i = 1; i <= n; i++) {
			Subject sub = new Subject();
			System.out.println("enter Subname : ");
			sub.setSubName(sc.next());

			sublist.add(sub);
		}

		s.setSubList(sublist);

		session.save(s);
		session.beginTransaction().commit();

	}

	@Override
	public void getStudentWithMultipleSubject() {
		Session session = sf.openSession();

		System.out.println("enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		if (s != null) {
			System.out.println(s);
		}

	}

	@Override
	public void updateStudent() {
		Session session = sf.openSession();

		System.out.println("enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		if (s != null) {
			System.out.println("Enter sname : ");
			s.setSname(sc.next());
			
			session.update(s);
			session.beginTransaction().commit();
		}

	}

	@Override
	public void updateStudentSubjectUsingSid() {
		Session session = sf.openSession();

		System.out.println("enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		if (s != null) {
			System.out.println(s);
			System.out.println("Enter subid : ");
			
			int subId=sc.nextInt();
			
			List<Subject> subList=s.getSubList();
			
			for(Subject sub:subList) {
				
				if(sub.getSubId()==subId) {
					System.out.println("enter subname : ");
					sub.setSubName(sc.next());
					session.update(s);
					session.beginTransaction().commit();
				}
				
			}
			
		}

	}

	@Override
	public void deleteStudentAndSubjects() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteSubjectOnly() {
		Session session = sf.openSession();

		System.out.println("enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		if (s != null) {
			System.out.println(s);
			System.out.println("Enter subid : ");
			
			int subId=sc.nextInt();
			
			List<Subject> subList=s.getSubList();
			
			for(Subject sub:subList) {
				
				if(sub.getSubId()==subId) {
					
					subList.remove(sub);
					
					session.delete(sub);
					session.beginTransaction().commit();
					break;
				}
				
			}
			
		}
	}

	@Override
	public void deleteStudentOnly() {
		Session session = sf.openSession();

		System.out.println("enter sid : ");
		Student s = session.get(Student.class, sc.nextInt());

		if (s != null) {
			s.setSubList(null);
//			session.update(s);
			session.delete(s);
			session.beginTransaction().commit();
		}

		

	}

}
