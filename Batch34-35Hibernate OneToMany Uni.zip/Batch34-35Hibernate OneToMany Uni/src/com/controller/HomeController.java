package com.controller;

import com.services.Services;
import com.services.ServicesImpl;

public class HomeController {
	
	public static void main(String[] args) {
		
		Services s=new ServicesImpl();
		
//		s.addStudentWithMultipleSubject();\
		
//		s.getStudentWithMultipleSubject();
		
//		s.updateStudentSubjectUsingSid();
		
//		s.deleteSubjectOnly();
		
		s.deleteStudentOnly();

		
	}

}
