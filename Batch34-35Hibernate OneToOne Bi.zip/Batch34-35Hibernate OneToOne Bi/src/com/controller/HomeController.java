package com.controller;

import com.services.Services;
import com.services.ServicesImpl;

public class HomeController {
	
	public static void main(String[] args) {
		
		Services s=new ServicesImpl();
		
//		s.addPersonWithCard();
		
//		s.addCardWithPerson();
		
//		s.getPersonWithCard();
		
//		s.getCardWithPerson();
		
//		s.updatePersonUsingAid();
		
//		s.deleteCardAndPersonUsingPid();
		
//		s.deletePersonOnly();
		
//		s.deleteCardOnly();
		
		s.addExistingPersonToExistingCard();

		
	}

}
