package com.services;

public interface Services {
	
	void addPersonWithCard();
	
	void addCardWithPerson();
	
	void getPersonWithCard();
	
	void getCardWithPerson();
	
	void updatePersonUsingAid();
	
	void updateCardUsingPid();
	
	void deleteCardAndPersonUsingPid();
	
	void deletePersonOnly();
	
	void deleteCardOnly();
	
	void addExistingPersonToExistingCard();
	

}
