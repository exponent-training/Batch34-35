package com.services;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.AdharCard;
import com.model.Person;
import com.util.HibernateUtil;

public class ServicesImpl implements Services {

	Scanner sc = new Scanner(System.in);
	SessionFactory sf = HibernateUtil.getFactory();

	@Override
	public void addPersonWithCard() {

		Session session = sf.openSession();

		Person p = new Person();
		System.out.println("Enter pname : ");
		p.setPname(sc.next());

		AdharCard card = new AdharCard();
		System.out.println("Enter aname : ");
		card.setAname(sc.next());

		p.setCard(card);
		card.setPerson(p);

		session.save(p);
		session.beginTransaction().commit();

	}

	@Override
	public void addCardWithPerson() {

		Session session = sf.openSession();

		Person p = new Person();
		System.out.println("Enter pname : ");
		p.setPname(sc.next());

		AdharCard card = new AdharCard();
		System.out.println("Enter aname : ");
		card.setAname(sc.next());

		p.setCard(card);
		card.setPerson(p);

		session.save(card);
		session.beginTransaction().commit();

	}

	@Override
	public void getPersonWithCard() {

		Session session = sf.openSession();

		System.out.println("Enter pid : ");
		Person p = session.get(Person.class, sc.nextInt());

		if (p != null) {
			System.out.println(p);// p
		} else {
			System.out.println("Invalid Id");
		}

	}

	@Override
	public void getCardWithPerson() {
		Session session = sf.openSession();

		System.out.println("Enter aid : ");
		AdharCard a = session.get(AdharCard.class, sc.nextInt());

		if (a != null) {
//			System.out.println(a);// p
			System.out.println(a.getPerson());
		} else {
			System.out.println("Invalid Id");
		}
	}

	@Override
	public void updatePersonUsingAid() {

		Session session = sf.openSession();
		System.out.println("Enter aid : ");
		AdharCard a = session.get(AdharCard.class, sc.nextInt());

		if (a != null) {

			Person p = a.getPerson();

			System.out.println("Enter updated Name : ");
			p.setPname(sc.next());

			session.update(a);
			session.beginTransaction().commit();

		} else {
			System.out.println("Invalid id");
		}

	}

	@Override
	public void updateCardUsingPid() {

		Session session = sf.openSession();
		System.out.println("Enter pid : ");
		Person p = session.get(Person.class, sc.nextInt());

		if (p != null) {

			AdharCard a = p.getCard();

			System.out.println("Enter updated Name : ");
			a.setAname(sc.next());

			session.update(p);
			session.beginTransaction().commit();

		} else {
			System.out.println("Invalid id");
		}

	}

	@Override
	public void deleteCardAndPersonUsingPid() {
		// TODO Auto-generated method stub

		Session session = sf.openSession();

		System.out.println("Enter pid : ");
		Person p = session.get(Person.class, sc.nextInt());

		if (p != null) {
			session.delete(p);
			session.beginTransaction().commit();
		} else {
			System.out.println("Invalid id");
		}

	}

	@Override
	public void deletePersonOnly() {
		Session session = sf.openSession();

		System.out.println("Enter pid : ");
		Person p = session.get(Person.class, sc.nextInt());

		if (p != null) {
			
			AdharCard a=p.getCard();
			p.setCard(null);
			a.setPerson(null);

			session.delete(p);// adharCard
			session.beginTransaction().commit();
		} else {
			System.out.println("Invalid id");
		}
	}

	@Override
	public void deleteCardOnly() {
		Session session=sf.openSession();
		System.out.println("Enter aid : ");
		
		AdharCard a=session.get(AdharCard.class, sc.nextInt());

		if(a!=null) {
			
			Person p=a.getPerson();
			a.setPerson(null);
			p.setCard(null);
			
			session.delete(a);
			session.beginTransaction().commit();
			
		}else {
			System.out.println("Invalid id");
		}
	}

	@Override
	public void addExistingPersonToExistingCard() {
		Session session = sf.openSession();

		System.out.println("Enter pid : ");
		Person p = session.get(Person.class, sc.nextInt());
		
		System.out.println("Enter aid : ");
		AdharCard a=session.get(AdharCard.class, sc.nextInt());

		if (p != null && a!=null) {
			
			p.setCard(a);
			a.setPerson(p);
			
			session.update(p);
			session.beginTransaction().commit();
			
			
		} else {
			System.out.println("Invalid id");
		}
	}
		
	

}
