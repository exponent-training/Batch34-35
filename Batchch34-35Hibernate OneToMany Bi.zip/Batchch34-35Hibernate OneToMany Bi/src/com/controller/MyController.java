package com.controller;

import com.services.ServiceImpl;
import com.services.Services;

public class MyController {
	
	
	public static void main(String[] args) {
		
		Services s= new ServiceImpl();
		
//		s.addDoctorWithMultiplePerson();
		
//		s.deleteDoctor();
		
//		s.deletePerson();
		
//		s.deletePersonOnly();
		
		s.deleteDoctorOnly();
		
	}

}
