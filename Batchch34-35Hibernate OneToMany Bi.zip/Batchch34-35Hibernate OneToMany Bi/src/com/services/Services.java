package com.services;

public interface Services {
	
	void addDoctorWithMultiplePerson();
	
	void addPersonWithDoctor();
	
	void getDoctorWithAllPerson();
	
	void getPersonWithDoctor();
	
	void upadteDoctor();
	
	void upadtePerson();
	
	void updatePersonUsingDid();
	
	void updateDoctorUsingPid();
	
	void deleteDoctor();
	
	void deletePerson();
	
	void deletePersonOnly();
	
	void deleteDoctorOnly();

}
