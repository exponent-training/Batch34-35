package com.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.hibernateUtil.HibernateUtil;
import com.model.Doctor;
import com.model.Person;

public class ServiceImpl implements Services {

	SessionFactory sf = HibernateUtil.getSessionFactory();
	Scanner sc = new Scanner(System.in);
	
	
	@Override
	public void addDoctorWithMultiplePerson() {
		Session session=sf.openSession();
		
		Doctor d= new Doctor();
		
		System.out.println("Enter dname : ");
		d.setDname(sc.next());
		
		System.out.println("Enter how person u want to enter : ");
		int n=sc.nextInt();
		
		List<Person> plist=  new ArrayList<Person>();
		
		for(int i=1;i<=n;i++) {
			
			Person p= new Person();
			
			System.out.println("enter pname : ");
			p.setPname(sc.next());
			
			p.setDoctor(d);
			
			plist.add(p);
			
		}
		
		d.setPlis(plist);
		
		session.save(d);
		session.beginTransaction().commit();
		
	}
	@Override
	public void addPersonWithDoctor() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void getDoctorWithAllPerson() {
		Session session=sf.openSession();
		System.out.println("Enter did : ");
		Doctor d=session.get(Doctor.class, sc.nextInt());
		
		if(d!=null) {
			System.out.println(d);
		}
		
		
	}
	@Override
	public void getPersonWithDoctor() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void upadteDoctor() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void upadtePerson() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void updatePersonUsingDid() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void updateDoctorUsingPid() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void deleteDoctor() {
		Session session=sf.openSession();
		System.out.println("Enter did : ");//1
		Doctor d=session.get(Doctor.class, sc.nextInt());
		
		if(d!=null) {
			
			session.delete(d);
			session.beginTransaction().commit();
			
		}
		
	}
	@Override
	public void deletePerson() {
		
		Session session=sf.openSession();
		System.out.println("Enter pid : ");
		Person p=session.get(Person.class, sc.nextInt());
		
		if(p!=null) {
			session.delete(p);
			session.beginTransaction().commit();
		}
		
	}
	@Override
	public void deletePersonOnly() {
		Session session=sf.openSession();
		System.out.println("Enter pid : ");
		Person p=session.get(Person.class, sc.nextInt());
		
		if(p!=null) {
			
			Doctor d=p.getDoctor();
			p.setDoctor(null);//1
			List<Person> plist=d.getPlis();
			plist.remove(p);//2
			
			session.delete(p);
			session.beginTransaction().commit();
		}
		
		
	}
	@Override
	public void deleteDoctorOnly() {
		
		Session session=sf.openSession();
		System.out.println("Enter did : ");
		Doctor d=session.get(Doctor.class, sc.nextInt());
		
		if(d!=null) {
			
			List<Person> plist=d.getPlis();
			
			d.setPlis(null);//1
			
			for(Person p:plist) {
				p.setDoctor(null);//2
			}
			
			
			session.delete(d);
			session.beginTransaction().commit();
			
		}
		
	}

	
}
