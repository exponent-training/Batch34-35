package com.services;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.model.Address;
import com.model.Student;
import com.util.HibernateUtil;

public class ServicesImpl implements Services {

	Scanner sc = new Scanner(System.in);
	SessionFactory sf = HibernateUtil.getFactory();

	@Override
	public void addStudentWithAdddress() {

		Session session = sf.openSession();

		Student s = new Student();

		System.out.println("Student sname : ");
		s.setSname(sc.next());

		Address a = new Address();

		System.out.println("City : ");
		a.setCity(sc.next());

		s.setAddress(a);

		session.save(s);
//		session.save(a);
		session.beginTransaction().commit();

	}

	@Override
	public void getStudentWithAddress() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		int sid = sc.nextInt();

		Student s = session.get(Student.class, sid);

		System.out.println(s);

	}

	@Override
	public void updateStudentAndAddress() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		int sid = sc.nextInt();// 5

		Student s = session.get(Student.class, sid);// null

		if (s != null) {

			System.out.println("Enter sname : ");
			s.setSname(sc.next());

			Address a = s.getAddress();
			System.out.println("Enter City : ");
			a.setCity(sc.next());

			session.update(s);
			session.beginTransaction().commit();

		} else {
			System.out.println("Invalid id");
		}

	}

	@Override
	public void deleteStudentAndAddress() {
		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		int sid = sc.nextInt();// 5

		Student s = session.get(Student.class, sid);// null

		if (s != null) {

			session.delete(s);
			session.beginTransaction().commit();

		} else {
			System.out.println("Invalid id");
		}

	}

	@Override
	public void deleteStudentOnly() {

		Session session = sf.openSession();

		System.out.println("Enter sid : ");
		int sid = sc.nextInt();// 5

		Student s = session.get(Student.class, sid);// null

		if (s != null) {
			
			s.setAddress(null);
//			session.update(s);
			session.delete(s);
			session.beginTransaction().commit();

		} else {
			System.out.println("Invalid id");
		}

	}

}
