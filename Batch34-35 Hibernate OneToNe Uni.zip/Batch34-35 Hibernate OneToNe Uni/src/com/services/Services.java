package com.services;

public interface Services {
	
	void addStudentWithAdddress();
	
	void getStudentWithAddress();
	
	void updateStudentAndAddress();
	
	void deleteStudentAndAddress();
	
	void deleteStudentOnly();

}
