package com;

import javax.persistence.Cache;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
	public static void main(String[] args) {
		
//		Student s= new Student();
//		
//		s.setSid(18);
//		s.setSname("Abc");
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session session=sf.openSession();
		
//		Person p= new Person();
//		p.setPname("jack");
//		
//		session.save(p);
//		session.beginTransaction().commit();
		
		Student s=session.get(Student.class, 1);//1
		System.out.println(s);
		
		Person p=session.get(Person.class, 1);//2
		System.out.println(p);
		
		Session session1=sf.openSession();
		
		Cache cache=sf.getCache();
//		cache.evict(Student.class);
		cache.evictAll();//clear
		
		
		Student s1=session1.get(Student.class, 1);//1
		System.out.println(s1);
		
		Person p1=session1.get(Person.class, 1);//2
		System.out.println(p1);
		
		
		

		
		System.out.println("---------------------------------------------");
		
//		session.clear();//all cache clear
		
//		session.evict(p);//clear cache of particular obj
		
//		Student s1=session.get(Student.class, 1);//1
//		System.out.println(s1);
//		
//		Person p1=session.get(Person.class, 1);//3
//		System.out.println(p1);
		
//		
//		Student s2=session.get(Student.class, 1);//2
//		System.out.println(s2);
//		
//		Student s3=session.get(Student.class, 1);//2
//		System.out.println(s3);
		
	}

}
